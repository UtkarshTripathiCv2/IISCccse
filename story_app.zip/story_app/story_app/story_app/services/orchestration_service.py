import logging
import random
import os
from. import text_generation_service
from. import image_generation_service
from django.conf import settings

logger = logging.getLogger(__name__)

# Predefined styles to ensure visual cohesion between character and background
ART_STYLES = [
    "cinematic photo", "digital painting", "fantasy art", "anime style",
    "studio ghibli style", "steampunk concept art", "cyberpunk neon",
    "photorealistic", "watercolor painting", "epic oil painting"
]

# Common modifiers to improve image quality and guide the diffusion model
QUALITY_MODIFIERS = "ultra realistic, 4k, 8k, masterpiece, sharp focus, highly detailed, professional"
NEGATIVE_PROMPT = "ugly, deformed, disfigured, poor details, bad anatomy, extra limbs, blurry, pixelated, childish, cartoon, watermark, text, signature, jpeg artifacts"

def _construct_image_prompt(base_description: str, style: str) -> str:
    """
    Constructs a high-quality prompt for the diffusion model by combining
    a base description with style and quality keywords.
    """
    return f"{style}, {base_description}, {QUALITY_MODIFIERS}"

def generate_creative_content(user_prompt: str) -> dict:
    """
    The main orchestration function. It coordinates the entire generation process.

    Args:
        user_prompt: The initial prompt from the user.

    Returns:
        A dictionary containing the story, descriptions, and the final image URL.
    """
    logger.info("Orchestration started.")
    
    # Step 1: Generate narrative content (story and descriptions)
    narrative_content = text_generation_service.generate_narrative(user_prompt)
    logger.info("Narrative content received.")

    # Step 2: Select a shared art style for visual cohesion
    shared_style = random.choice(ART_STYLES)
    logger.info(f"Selected shared art style: {shared_style}")

    # Step 3: Construct enhanced prompts for image generation
    character_prompt = _construct_image_prompt(narrative_content['character_description'], shared_style)
    background_prompt = _construct_image_prompt(narrative_content['background_description'], shared_style)

    # Step 4: Generate character and background images sequentially
    logger.info("Generating character image...")
    character_image_url = image_generation_service.generate_image(character_prompt, NEGATIVE_PROMPT, is_character=True)
    
    logger.info("Generating background image...")
    background_image_url = image_generation_service.generate_image(background_prompt, NEGATIVE_PROMPT)

    # Convert URLs to absolute filesystem paths for processing by Pillow
    character_fs_path = os.path.join(settings.MEDIA_ROOT, os.path.basename(character_image_url))
    background_fs_path = os.path.join(settings.MEDIA_ROOT, os.path.basename(background_image_url))

    # Step 5: Composite the images into a final scene
    final_image_url = image_generation_service.remove_background_and_composite(
        character_fs_path,
        background_fs_path
    )
    logger.info("Orchestration complete.")

    # Step 6: Return all generated assets to the view
    return {
        'story': narrative_content['story'],
        'character_description': narrative_content['character_description'],
        'background_description': narrative_content['background_description'],
        'final_image_url': final_image_url,
    }