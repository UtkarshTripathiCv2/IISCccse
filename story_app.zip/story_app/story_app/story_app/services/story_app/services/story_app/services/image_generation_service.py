import torch
from diffusers import DiffusionPipeline
from PIL import Image
import os
from django.conf import settings
import uuid
import logging
import math

logger = logging.getLogger(__name__)

# Global variable to hold the pipeline, so it's loaded only once per server run.
pipeline = None

def _load_pipeline():
    """Loads the Stable Diffusion pipeline into memory. This is a heavy, one-time operation."""
    global pipeline
    if pipeline is None:
        logger.info("Loading Stable Diffusion pipeline for the first time... This will take several minutes.")
        model_id = "stabilityai/stable-diffusion-xl-base-1.0"
        
        if not torch.cuda.is_available():
            logger.error("CUDA is not available. Image generation requires an NVIDIA GPU.")
            raise RuntimeError("CUDA not available. Cannot run Stable Diffusion.")
        
        try:
            pipeline = DiffusionPipeline.from_pretrained(
                model_id,
                torch_dtype=torch.float16,
                use_safetensors=True,
                variant="fp16"
            )
            pipeline.to("cuda")
            logger.info("Stable Diffusion pipeline loaded successfully to GPU.")
        except Exception as e:
            logger.error(f"Failed to load the diffusion pipeline: {e}", exc_info=True)
            pipeline = None # Ensure it remains None on failure
            raise RuntimeError(f"Failed to load diffusion pipeline. Check model name and network connection. Error: {e}")

def generate_image(prompt: str, negative_prompt: str, is_character: bool = False) -> str:
    """
    Generates an image using Stable Diffusion and saves it.

    Args:
        prompt: The text prompt for the image.
        negative_prompt: The negative prompt.
        is_character: Flag to indicate if we are generating a character,
                      which adds a green background for chroma keying.

    Returns:
        The URL path to the saved image.
    """
    _load_pipeline()
    if pipeline is None:
        raise RuntimeError("Image generation pipeline is not available.")

    if is_character:
        prompt += ", on a solid vibrant green background"
    
    logger.info(f"Generating image with prompt: {prompt}")
    
    # Use a random seed for variety
    generator = torch.Generator("cuda").manual_seed(uuid.uuid4().int & (1<<64)-1)
    
    with torch.no_grad():
        image = pipeline(
            prompt=prompt,
            negative_prompt=negative_prompt,
            num_inference_steps=25,
            guidance_scale=7.5,
            generator=generator
        ).images

    os.makedirs(settings.MEDIA_ROOT, exist_ok=True)
    filename = f"{uuid.uuid4()}.png"
    filepath = os.path.join(settings.MEDIA_ROOT, filename)
    image.save(filepath)
    logger.info(f"Image saved to {filepath}")
    
    return os.path.join(settings.MEDIA_URL, filename)

def _color_distance(c1, c2):
    """Calculates the Euclidean distance between two RGB colors."""
    r1, g1, b1 = c1
    r2, g2, b2 = c2
    return math.sqrt((r1 - r2)**2 + (g1 - g2)**2 + (b1 - b2)**2)

def remove_background_and_composite(character_image_path: str, background_image_path: str) -> str:
    """
    Removes the green screen from the character image and composites it
    onto the background image.

    Args:
        character_image_path: Filesystem path to the character image.
        background_image_path: Filesystem path to the background image.

    Returns:
        The URL path to the final composited image.
    """
    logger.info("Starting image composition process...")
    
    char_img = Image.open(character_image_path).convert("RGBA")
    bg_img = Image.open(background_image_path).convert("RGBA")

    # Resize character to be smaller than the background (e.g., 70% of height)
    new_char_height = int(bg_img.height * 0.7)
    char_aspect_ratio = char_img.width / char_img.height
    new_char_width = int(new_char_height * char_aspect_ratio)
    char_img = char_img.resize((new_char_width, new_char_height), Image.Resampling.LANCZOS)

    # Chroma keying (background removal)
    char_data = char_img.getdata()
    new_data =
    
    key_color = (0, 255, 0)
    tolerance = 150 # Adjust based on green screen consistency
    
    for item in char_data:
        if _color_distance(item[:3], key_color) < tolerance:
            new_data.append((255, 255, 255, 0)) # Make pixel transparent
        else:
            new_data.append(item)
            
    char_img.putdata(new_data)

    # Composite the images
    paste_x = (bg_img.width - char_img.width) // 2
    paste_y = bg_img.height - char_img.height
    
    composite_img = bg_img.copy()
    # The third argument (char_img) acts as the alpha mask
    composite_img.paste(char_img, (paste_x, paste_y), char_img)

    filename = f"composite_{uuid.uuid4()}.png"
    filepath = os.path.join(settings.MEDIA_ROOT, filename)
    composite_img.save(filepath)
    logger.info(f"Composited image saved to {filepath}")
    
    return os.path.join(settings.MEDIA_URL, filename)