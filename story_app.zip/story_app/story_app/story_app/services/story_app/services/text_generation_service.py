import os
import logging
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.exceptions import OutputParserException

logger = logging.getLogger(__name__)

# This template instructs the model on its role, the task, and the required output format.
# Using a structured format like JSON is far more robust than free-form text.
NARRATIVE_PROMPT_TEMPLATE = """
You are a world-class creative writer and concept artist. Your task is to take a user's prompt and generate a cohesive narrative package.
Based on the user's prompt below, you must generate a complete and valid JSON object with three distinct keys: "story", "character_description", and "background_description".

USER PROMPT: "{user_prompt}"

DETAILED INSTRUCTIONS:
1.  **story**: Write a short, engaging story of approximately 250-300 words. The story should be imaginative and set a clear scene.
2.  **character_description**: Provide a detailed VISUAL description of the main character. Focus on physical appearance, clothing, gear, and key distinguishing features. This description will be used to generate an image, so be specific about visual elements. Do not describe personality or thoughts, only what can be seen.
3.  **background_description**: Provide a detailed VISUAL description of the environment, setting, or background. Focus on the location, time of day, lighting, weather, and overall mood. This description will also be used to generate an image.

YOUR RESPONSE (must be a single, valid JSON object and nothing else):
"""

def generate_narrative(prompt_text: str) -> dict:
    """
    Uses LangChain and Google Gemini to generate a story, character description,
    and background description from a user prompt.

    Args:
        prompt_text: The user's input prompt.

    Returns:
        A dictionary with 'story', 'character_description', and 'background_description'.

    Raises:
        ValueError: If the API key is not configured.
        RuntimeError: If the LLM fails to produce parsable JSON or another error occurs.
    """
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key:
        logger.error("GOOGLE_API_KEY not found in environment variables.")
        raise ValueError("Google API Key is not configured. Please set it in the.env file.")

    # Initialize the language model
    llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=api_key, temperature=0.8)
    
    # Initialize the JSON output parser
    parser = JsonOutputParser()
    
    # Create the prompt template
    prompt_template = ChatPromptTemplate.from_template(
        template=NARRATIVE_PROMPT_TEMPLATE
    )
    
    # Create the LangChain chain by piping components together
    chain = prompt_template | llm | parser
    
    logger.info("Invoking text generation chain...")
    try:
        # Invoke the chain and get the structured output
        response = chain.invoke({"user_prompt": prompt_text})
        logger.info("Successfully parsed response from LLM.")
        return response
    except OutputParserException as e:
        logger.error(f"Failed to parse LLM output as JSON: {e}")
        raise RuntimeError("Failed to get a valid structured response from the language model. The model's output was not valid JSON.")
    except Exception as e:
        logger.error(f"An unexpected error occurred in text generation: {e}", exc_info=True)
        raise RuntimeError(f"An unexpected error occurred during text generation: {e}")