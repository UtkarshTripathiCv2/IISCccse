from django.shortcuts import render
import logging
from.services import orchestration_service

# Configure logging to see output in the console
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def index_view(request):
    """
    Handles the main page logic. Acts as a "thin controller".
    - On GET, it displays the initial form.
    - On POST, it processes the user's prompt, calls the orchestration
      service to generate content, and displays the results.
    """
    context = {}
    if request.method == 'POST':
        prompt = request.POST.get('prompt', '').strip()
        
        if prompt:
            try:
                # Delegate the complex generation logic to the service layer
                logger.info(f"Received prompt: '{prompt}'")
                result = orchestration_service.generate_creative_content(prompt)
                context.update(result)
                context['prompt'] = prompt
                logger.info("Successfully generated and returned content to view.")
            except Exception as e:
                # Log the full exception for debugging
                logger.error(f"An error occurred during content generation: {e}", exc_info=True)
                context['error'] = "An unexpected error occurred. Please check the server logs or try a different prompt."
        else:
            context['error'] = "The prompt cannot be empty. Please enter a creative idea."
            
    return render(request, 'story_app/index.html', context)