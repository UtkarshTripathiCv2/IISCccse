# In creative_story_generator/urls.py

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # This route is for the Django admin interface
    path('admin/', admin.site.urls),

    # This tells Django to look for other URLs in your 'story_app'
    path('', include('story_app.urls')),
]